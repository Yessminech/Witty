#ifndef _PARASITE_PWM_H_
#define _PARASITE_PWM_H_

namespace parasite {
namespace pwm {

void StartPWM();
void StopPWM();

}  // namespace batt
}  // namespace parasite

#endif  // _PARASITE_PWM_H_