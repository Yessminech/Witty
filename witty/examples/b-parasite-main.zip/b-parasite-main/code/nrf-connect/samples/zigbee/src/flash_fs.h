#ifndef _PRST_FLASH_FS_H_
#define _PRST_FLASH_FS_H_

#include <stddef.h>

// Initializes and mounts littlefs.
int prst_flash_fs_init();

#endif  // _PRST_FLASH_FS_H_