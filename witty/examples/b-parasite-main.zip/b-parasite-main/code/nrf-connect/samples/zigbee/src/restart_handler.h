#ifndef _PRST_ZB_RESTART_HANDLER_H_
#define _PRST_ZB_RESTART_HANDLER_H_

void prst_restart_watchdog_start();
void prst_restart_watchdog_stop();

#endif  // _PRST_ZB_RESTART_HANDLER_H_
