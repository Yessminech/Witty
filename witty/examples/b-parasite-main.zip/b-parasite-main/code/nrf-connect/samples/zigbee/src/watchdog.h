#ifndef _PRST_ZB_WATCHDOG_H_
#define _PRST_ZB_WATCHDOG_H_

int prst_watchdog_start();

int prst_watchdog_feed();

#endif  // _PRST_ZB_WATCHDOG_H_